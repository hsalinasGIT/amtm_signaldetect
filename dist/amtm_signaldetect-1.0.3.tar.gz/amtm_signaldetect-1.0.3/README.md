# amtm_signaldetect
Periodic Signal Detection via the Adaptive Multitaper Method (aMTM)
###
Please refer to the v10x_amtm_tutorial.ipynb Jupyter notebook for details on how to use the package

# amtm_signaldetect
Periodic Signal Detection via the Adaptive Multitaper Method (aMTM)
###
Please refer to the v10x_amtm_tutorial.ipynb Jupyter notebook for details on how to use the package
[![DOI](https://zenodo.org/badge/829512565.svg)](https://doi.org/10.5281/zenodo.14774370)

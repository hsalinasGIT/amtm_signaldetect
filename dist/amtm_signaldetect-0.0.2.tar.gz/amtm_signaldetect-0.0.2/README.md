# amtm_signaldetect
Periodic Signal Detection via the Adaptive Multitaper Method (aMTM)

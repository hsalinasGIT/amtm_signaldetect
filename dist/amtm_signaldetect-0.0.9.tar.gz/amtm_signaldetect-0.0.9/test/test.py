from amtm_signaldetect.aMTMSignalDetect import *

def test_foo():
    print(help(get_amtm_specs) )